package org.moita.common.services;

public enum TransformationType
{
    SIMPLE,
    COMPLEX
}
